# mac-projects
how to run my programe

1) go to file location
2) right click on file
3) open properties
4) change "open with:" to python from vs code
5) open file
6) run menu following cli prompts

---

**week_1// early week_2: basic build**

start with the 'def' function to build my menu

allowing choices '0,1,2' to make a selection of products menu, orders menu and exit

enter product menu allows you to select to view the product menu or add a product menu

entering orders menu printed out a pre-made orders example while letting you input user data stored in RAM (data storage not yet set up) already in a dictionary!!!

missed the strech activity

---

**week_2: improvments for original**

rebuilt the menu system made it more streamlined but kept the frame work consistant with previous work

fixed the half baked orders menu made it significantly better and more structured following while true if elif else statements

---

**week_3: the troubles**

csv is difficult to say the least but ive kinda figured it out (big emphasis on kinda)

by changing my code structure ive made it so all my data is sent into csv files

maintained the basic structure from previous weeks with 'def' funtion

built my courier menu again and again and again: it works now

made my products list output into csv

---

week_4+: 
brought in csv file system for all menu sections
brought in save data for each section of the code to store data
couriers menu bult in dictionary format to keep stored data together
---
orders menu developed futher for more functionality
added view all orders function for added data to be viewed
added order status update function 
no changes made to products or couriers menu
---
Where i fell short:
i missed listing orders by status or courier (a bonus task)
i missed out on setting up unit testing 
i missed creating a database
i missed adding a product or courier to a database table
i missed data persist in a database 
---
Project design requirments:
i belive i met the majority of the requirements but fell short of the completed project 
losing my inital work due to docker issues set me back
along with stubborn learning habits of figuring thing's out myself
---
with more time:
databases would be set up and
products would be loaded with id numbers instead of index in database
some basic unit testing for my functions would be built out
---
what did i enjoy:
dictionaries clicked with me really quick understood them right off the bat
i mostly enjoyed blaring music and writing code out at least till i had to fix something
